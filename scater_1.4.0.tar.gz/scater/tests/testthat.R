library(testthat)
library(scater)

test_check("scater")
