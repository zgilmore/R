# The `scater` package sticker

* Maintainer: [Davis McCarthy](https://github.com/davismcc/)
* License: Creative Commons Attribution
[CC-BY](https://creativecommons.org/licenses/by/2.0/). Feel free to
share and adapt, but don't forget to credit the author.

<img src=scater_sticker_300dpi.png height="200">

Skateboard icon made by [Nikita Golubev](http://www.flaticon.com/authors/nikita-golubev) from [Flaticon](http://www.flaticon.com) is licensed by [Creative Commons BY 3.0](http://creativecommons.org/licenses/by/3.0/).
