# whee <- function(object){
#     sizeFactors(object)
# }
# 
# setMethod("normalize", "SummarizedExperiment", function(object) "whee")
# 
